package com.example.dell.goayur;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page_activity);
    }
    public void listOfDoctor(View view) {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    public void aboutUs(View view) {
        Intent intent = new Intent(this,AboutUs.class);
        startActivity(intent);
    }

    public void contactUs(View view) {
        Intent intent = new Intent(this,ContactUs.class);
        startActivity(intent);
    }
}
