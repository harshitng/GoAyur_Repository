package com.example.dell.goayur;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Appointment_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
    }
}
